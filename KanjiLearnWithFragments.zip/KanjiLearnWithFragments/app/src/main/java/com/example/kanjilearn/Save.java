package com.example.kanjilearn;

import android.app.Application;

public class Save extends Application {
    private int i = 0;
    public int ap(){
        return i++;
    }
}
