package com.example.kanjilearn;

import android.support.v4.app.Fragment;

public interface FragmentChangeListener {
    public void replaceFragment(Fragment fragment);
}
