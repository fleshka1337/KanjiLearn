package com.example.kanjilearn;

public interface FragmentListener {
    void onItemClick(String value);
}
